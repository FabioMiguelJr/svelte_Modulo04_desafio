<script>

  function exemploMediaRecorder(stream) {
    // Para gravar áudio devemos criar um MediaRecorder passando o stream
    let mediaRecorder = new MediaRecorder(stream);

    let chunks = [];
    mediaRecorder.ondataavailable = function(e) {
      // A cada evento dataavailable, uma parte do áudio é disponibilizada.
      // Devemos armazenar os dados do evento para depois juntar todas as
      // partes no arquivo de áudio final.
      chunks.push(e.data);
    }

    mediaRecorder.onstop = function(e) {
      // No evento stop, podemos juntar as partes do áudio usando
      // um objeto Blob, especificando o tipo audio/ogg
      const blob = new Blob(chunks, { 'type' : 'audio/ogg; codecs=opus' });
      // Criamos um outro array chunks para usar na próxima gravação
      chunks = [];

      // Agora transformamos o Blob em uma URL de dados.
      // Podemos usá-la como src de um elemento <audio>.
      const audioURL = URL.createObjectURL(blob);
    }

    // Esta função deve ser chamada para iniciar a gravação.
    // mediaRecorder.start();

    // E esta outra para parar a gravação.
    // mediaRecorder.stop();
  }
</script>

<main>
  <h1>Gravador de áudio</h1>
</main>

<style>
  
</style>